from kivymd.uix.boxlayout import MDBoxLayout


class KitchenSinkExpansionPanelContent(MDBoxLayout):
    pass
