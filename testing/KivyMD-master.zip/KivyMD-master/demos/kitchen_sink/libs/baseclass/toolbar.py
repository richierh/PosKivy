from kivymd.uix.toolbar import MDToolbar


class Toolbar(MDToolbar):
    pass
