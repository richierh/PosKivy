# KivyMD Icon Viewer

![](screenshot/0001.png)
![](screenshot/0002.png)

- Works without having KivyMD installed.
- [Youtube Demo](https://youtu.be/h_ARi0fqnLw)
